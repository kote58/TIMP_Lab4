var indexSectionsWithContent =
{
  0: "cdegst",
  1: "c",
  2: "t",
  3: "cdegs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции"
};

