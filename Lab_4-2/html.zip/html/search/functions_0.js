var searchData=
[
  ['cipher_15',['Cipher',['../classCipher.html#ae728d0917db639dd49638a268298391f',1,'Cipher::Cipher()=delete'],['../classCipher.html#a876edcc7064f450935baedce442f1556',1,'Cipher::Cipher(std::wstring &amp;ws_key)']]],
  ['cipher_5ferror_16',['cipher_error',['../classcipher__error.html#aac662e216a84bfeb873303c7b88d029e',1,'cipher_error::cipher_error(const std::string &amp;what_arg)'],['../classcipher__error.html#a18cf27d9c2cd2538d3cb8f17e9a55f3e',1,'cipher_error::cipher_error(const char *what_arg)']]]
];
