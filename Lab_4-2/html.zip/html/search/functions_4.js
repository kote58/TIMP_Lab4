var searchData=
[
  ['set_5fkey_22',['set_key',['../classCipher.html#a86145f7c206e6d75852a28ffe29dc47a',1,'Cipher']]],
  ['set_5ftext_23',['set_text',['../classCipher.html#ac3b5a2e01d031dae879d2fcacbc6620e',1,'Cipher']]]
];
